﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC_Hospital
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*** Welcome to ABC Hospital ***");

            

            Console.WriteLine("Enter your Choice for Query \n 1. Add Doctor Details \n 2.Find Doctor By Name \n 3. Display All Doctor Details \n 4. Change Department for a Doctor ");

            int Choice = Int32.Parse(Console.ReadLine());

            Doctor Idoc = new Doctor();
            do
            {
                switch (Choice)
                {
                    case 1:
                        Console.WriteLine("Your Choice is :" + Choice);
                        Idoc.AddDoctor();
                        break;

                    case 2:
                        Console.WriteLine("Your Choice is :" + Choice);
                        Idoc.FindDoctorByName();
                        break;

                    case 3:
                        Console.WriteLine("Your Choice is :" + Choice);
                        Idoc.DisplayAllDoctorDetail();
                        break;

                    case 4:
                        Console.WriteLine("Your Choice is :" + Choice);
                        Idoc.UpdateDoctorDepartment();
                        break;

                    default:
                        Console.WriteLine("Wrong Choice");
                        break;


                }

            } while (Choice < 5);
        }  
    }
}

            

        
    

