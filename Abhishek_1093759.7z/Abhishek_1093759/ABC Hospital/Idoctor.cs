﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC_Hospital
{
    interface Idoctor
    {
        void AddDoctor( string _NAME , int _DoctorID , string _DeptName);
        void FindDoctorByName(string _NAME);
        void DisplayAllDoctorDetail(string _NAME, int _DoctorID, string _DeptName);
        void UpdateDoctorDepartment(int _DoctorID, string _DeptName);
    }
}
