﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC_Hospital
{
    class Person : Idoctor
    {
        
       
        string Name;

        public string _NaME
        {
            get
            {
                return Name;
            }
            set
            {
                value = Name;
            }
        }

       
    }
    
}
