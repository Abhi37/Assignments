﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC_Hospital
{
    class Doctor: Person
    {
        int DoctorId;
        string DeptName;
        string Name;
        List<Doctor> DocObject = new List<Doctor>();
        Doctor Doc = new Doctor();
      
        public int _DoctorID
        {
            get { 
                return DoctorId; }
            set { 
                value = DoctorId; }
        }
        public string _DeptName
        {
            get 
            {
                return DeptName;
            }
                
            set
            {
                value = DeptName;
            }
        }
        public string _NAME
        {
            get
            {
                return Name;
            }
            set
            {
                value = Name;
            }
        }

        public void AddDoctor()
        {
            Console.WriteLine("Enter the Id of the Doctor :");
            Doc._DoctorID = Int32.Parse(Console.ReadLine());
            Doc._DeptName = Console.ReadLine();
            Doc._NAME = Console.ReadLine();
            
        }

        public void FindDoctorByName()
        {
            Console.WriteLine("Enter Name of the Doctor you want Information about : ");

                        string DocNm = Console.ReadLine();

                        if (DocNm == Doc._NAME)
                        {
                            Console.WriteLine("Details of Dr. " + DocNm);

                            Console.WriteLine(Doc._DoctorID);

                            Console.WriteLine(Doc._DeptName);
                        }
                        else
                        {
                            Console.WriteLine("Enter the Correct Doctor name :");
                        }

        }


        public void DisplayAllDoctorDetail()
        {
            Console.WriteLine("current data of all available doctor is as follows:");


        }


        public void UpdateDoctorDepartment()
        {
            Console.WriteLine("Enter the Doctors Id :");
                        int Did = Int32.Parse(Console.ReadLine());

                        if (Did == Doc._DoctorID)
                        {
                            Console.WriteLine("Enter the new Dept Name For Doctor Id: " + Did);

                            string NewDept = Console.ReadLine();

                            Doc._DeptName = NewDept;

                           Console.WriteLine("New Department is : " + Doc._DeptName);


                        }

        }

       
                    



                 
                  
    }
}
