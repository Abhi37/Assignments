﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FastQuoteInsurance_Mvc.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Home()
        {
            return View();
        }
        public ActionResult AbtConFaq()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult FQPortal()
        {
            return View();
        }
        public ActionResult AccidentHistoryEdit()
        {
            return View();
        }
        public ActionResult AccidentHistoryView()
        {
            return View();
        }
        public ActionResult ConvictionHistoryEdit()
        {
            return View();
        }
        public ActionResult ConvictionHistoryView()
        {
            return View();
        }
        public ActionResult QuoteMgmt()
        {
            return View();
        }
    }
}