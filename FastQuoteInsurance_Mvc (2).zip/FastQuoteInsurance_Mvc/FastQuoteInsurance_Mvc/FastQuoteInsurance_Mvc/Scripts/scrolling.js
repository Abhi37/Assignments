﻿
$(function () {
    $(window).on("load resize", function () {
        $(".fill-screen").css("height", window.innerHeight);
    }); 

    // add Bootstrap's scrollspy
    $('section').scrollspy({
        target: '.navbar',
        offset: 160
    });

    // smooth scrolling
    $('nav a, .down-button a').bind('click', function () {
        $('html, body').stop().animate({
            scrollTop: $($(this).attr('href')).offset().top +1050
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });

    //parallax scrolling with steller.js
    $(window).steller();

    // initialize WOW for element animation
    new WOW().init();

});