﻿/*Login Static Cresential*/
function check(form) {
    var U = document.getElementById("username").value;
    var P = document.getElementById("password").value;
    if (U === "" || P === "") {
        alert("Please Enter Usename or Password");
    }
    else if (U == "admin" && P == "admin") {
        window.open("UserInteraction.aspx");/*opens the target page while Id & password matches*/
    }
    else {
        alert("Access Denied/Wrong User Name Password");/*displays error message*/
    }
}

/*Login End*/


/*Vertical Bar */
//var main = document.getElementById("wrapper");
//main.onmouseenter = fuction() {
//    main.style.backgroundColor = #888;
//}

(function () {

    var $sidebarAndWrapper = $("#sidebar, #wrapper");

    $("#sidebarToggle").on("click", function () {

        $sidebarAndWrapper.toggleClass("hide-sidebar");
    });
})();

//Vertcal Nav Bar
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function openNav() {
    
        document.getElementById("mySidenav").style.width = "250px";
}
function button() {
    if (document.getElementById("mySidenav").style.width = "0px") {
        openNav();
    }
    else {
        closeNav();
    }
}




//$(function () {
//    $("#mySidebar").mySidebar();
//});