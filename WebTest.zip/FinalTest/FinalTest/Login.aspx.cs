﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace FinalTest
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            SqlConnection cn = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand("sp_check", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("Username", txtLUname.Text);
            cmd.Parameters.AddWithValue("UPassword", txtLpswd.Text);
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count>0)
            {
                Response.Redirect("User.aspx");
            }
            else
            {
                Response.Write("Invalid");
            }
        }
    }
}