﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace FinalTest
{
    public partial class RegPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_reg_Click(object sender, EventArgs e)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            SqlConnection cn = new SqlConnection(conString);
            SqlCommand cmd =new SqlCommand("RegUser", cn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Name", txtname.Text);
            cmd.Parameters.AddWithValue("@UserName", txtUname.Text);
            cmd.Parameters.AddWithValue("@UPassword", txtpswd.Text);

            cn.Open();
            SqlDataReader Dr = cmd.ExecuteReader();
            if (Dr.HasRows)
            {
                lblRstatus.Text = "Invaild UserName";
                lblRstatus.Visible = true;
            }
            else
            {
                lblRstatus.Text = "Registration Successful";
                lblRstatus.Visible = true;
            }
        }
    }
}