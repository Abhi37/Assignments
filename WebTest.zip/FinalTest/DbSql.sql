Use master

create database LoginDB
go

Use LoginDB


Set Ansi_nulls On
GO

create table userReg1
(Name varchar(100),
UserName varchar(100) primary key not null,
UPassword varchar(100),
)

select * from userReg1
alter Procedure RegUser
(@Name varchar(100),
@UserName varchar(100),
@UPassword varchar(100)
)
As
Begin
Insert into userReg1(Name , UserName, UPassword)
Values(@Name , @UserName, @UPassword)
END

create procedure sp_check
(@UserName varchar(100),
@UPassword varchar(100)
)
As 
Begin
select * from userReg1 where UserName= @UserName AND UPassword = @UPassword
End
